package com.black.xperiments.graphviewrecyclerview

import com.jjoe64.graphview.series.DataPoint
import com.jjoe64.graphview.series.LineGraphSeries

data class GraphObject(
    var title:String,
    var switchState:Boolean,
    var signalSeries: LineGraphSeries<DataPoint>,
    var lowerThresholdSeries: LineGraphSeries<DataPoint>,
    var upperThresholdSeries: LineGraphSeries<DataPoint>)