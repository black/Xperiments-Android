package com.black.xperiments.graphviewrecyclerview

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.lang.Math.random

class SensorSim constructor(
    context: Context,
){
    private var sensorStream:SensorStream?=null
    private var time = 1L
    private val handler= Handler(Looper.getMainLooper())
    init {
    }

    // speed
    fun starSensor(){
        handler.postDelayed(runnable, 0)
    }

    fun stopSensor(){
        handler.removeCallbacks(runnable)
    }

    private val runnable: Runnable = object : Runnable {
        override fun run() {
            handler.postDelayed(this, time * 1000)
            sensorStream?.data(random()*100)
        }
    }

}