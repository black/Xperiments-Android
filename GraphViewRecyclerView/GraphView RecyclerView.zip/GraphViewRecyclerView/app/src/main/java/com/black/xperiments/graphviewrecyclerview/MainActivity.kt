package com.black.xperiments.graphviewrecyclerview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.black.xperiments.graphviewrecyclerview.databinding.ActivityMainBinding
import com.jjoe64.graphview.GraphView
import com.jjoe64.graphview.series.DataPoint
import com.jjoe64.graphview.series.LineGraphSeries

class MainActivity : AppCompatActivity(),SensorStream {
    private lateinit var binding: ActivityMainBinding
    private var rvGraphViewAdapter:RecyclerViewGraphViewAdapter?=null
    private var graphViewDataList  = arrayListOf<GraphObject>()
    private var sensorSim:SensorSim?=null

    private var signalSeries = LineGraphSeries<DataPoint>()
    private var upperThresholdSeries = LineGraphSeries<DataPoint>()
    private var lowerThresholdSeries = LineGraphSeries<DataPoint>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        rvGraphViewAdapter = RecyclerViewGraphViewAdapter(this,graphViewDataList)
        binding.graphViewList.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
            adapter = rvGraphViewAdapter
        }
        sensorSim = SensorSim(this)
        sensorSim?.starSensor()

        setGraphObjectList()
    }

    override fun data(value: Double) {

    }

    private fun setGraphObjectList(){
        graphViewDataList.add(GraphObject("Signal 1",true,signalSeries,upperThresholdSeries,lowerThresholdSeries))
        graphViewDataList.add(GraphObject("Signal 2",true,signalSeries,upperThresholdSeries,lowerThresholdSeries))
        graphViewDataList.add(GraphObject("Signal 3",true,signalSeries,upperThresholdSeries,lowerThresholdSeries))
        graphViewDataList.add(GraphObject("Signal 4",true,signalSeries,upperThresholdSeries,lowerThresholdSeries))
        graphViewDataList.add(GraphObject("Signal 5",true,signalSeries,upperThresholdSeries,lowerThresholdSeries))
    }

}