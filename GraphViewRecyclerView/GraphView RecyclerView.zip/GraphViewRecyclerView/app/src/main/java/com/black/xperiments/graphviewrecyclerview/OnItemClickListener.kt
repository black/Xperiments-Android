package com.black.xperiments.graphviewrecyclerview

interface OnItemClickListener {
    fun onItem(position:Int)
}