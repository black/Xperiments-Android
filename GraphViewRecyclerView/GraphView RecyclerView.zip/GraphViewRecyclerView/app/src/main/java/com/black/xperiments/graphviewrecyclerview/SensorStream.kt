package com.black.xperiments.graphviewrecyclerview

interface SensorStream {
    fun data(value:Double)
}