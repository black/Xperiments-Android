package com.black.xperiments.readwritefile.common

interface OnClickListener {
    fun onClick(pos: Int)
}
